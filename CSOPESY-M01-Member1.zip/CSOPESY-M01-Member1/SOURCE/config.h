#ifndef CONFIG_H
#define CONFIG_H

#include <cstdint>
#include <string>

struct Config {
    int numCpu = 0;
    std::string scheduler;

    std::uint64_t quantumCycles = 0;
    std::uint64_t batchProcessFreq = 0;
    std::uint64_t minIns = 0;
    std::uint64_t maxIns = 0;
    std::uint64_t delaysPerExec = 0;
};

// Loads and validates the configuration file.
bool loadConfig(
    const std::string& filename,
    Config& config,
    std::string& errorMessage
);

#endif
