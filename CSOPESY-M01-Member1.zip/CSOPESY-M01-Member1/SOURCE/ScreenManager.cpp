#include "ScreenManager.h"

#include <iostream>

ScreenManager::ScreenManager(
    ProcessManager& manager
)
    : processManager(manager) {
}

bool ScreenManager::openScreen(
    const std::shared_ptr<Process>& process
) {
    if (attached || !process) {
        return false;
    }

    if (
        processManager.findProcessByPid(
            process->pid
        ) != process
    ) {
        return false;
    }

    // Keep the initial screen available even if execution has finished.
    currentProcess = process;
    attached = true;

    clearConsole();

    displayScreen();

    return true;
}

bool ScreenManager::reattachScreen(
    const std::shared_ptr<Process>& process
) {
    if (attached || !process) {
        return false;
    }

    const ProcessSnapshot information =
        process->snapshot();

    if (
        information.state ==
        ProcessState::TERMINATED
    ) {
        std::cout
            << "Process "
            << information.name
            << " not found.\n";

        return false;
    }

    return openScreen(process);
}

void ScreenManager::displayScreen() const {
    if (!attached || !currentProcess) {
        std::cout
            << "No process screen is currently open.\n";

        return;
    }

    const ProcessSnapshot process =
        currentProcess->snapshot();

    std::cout
        << "\n====================================\n"
        << "            PROCESS SCREEN\n"
        << "====================================\n"
        << "Process name: "
        << process.name
        << "\nID: "
        << process.pid
        << "\nState: "
        << stateName(process.state)
        << "\nAssigned core: ";

    if (process.assignedCore < 0) {
        std::cout << "None";
    }
    else {
        std::cout << process.assignedCore;
    }

    std::cout << "\nLogs:\n";

    if (process.logs.empty()) {
        std::cout << "No output yet.\n";
    }

    for (const std::string& line : process.logs) {
        std::cout << line << '\n';
    }

    std::cout
        << "Current instruction line: "
        << process.instructionPointer
        << "\nLines of code: "
        << process.totalInstructions
        << '\n';

    if (
        process.state ==
        ProcessState::TERMINATED
    ) {
        std::cout << "Finished!\n";
    }

    std::cout
        << "Commands: process-smi, help, exit\n";
}

void ScreenManager::detachScreen() {
    // Does not stop or delete the process.
    currentProcess.reset();
    attached = false;

    clearConsole();
}

bool ScreenManager::isAttached() const {
    return attached;
}

std::shared_ptr<Process>
ScreenManager::getCurrentProcess() const {
    return currentProcess;
}

void ScreenManager::clearConsole() const {
    std::cout << "\x1b[2J\x1b[H" << std::flush;
}

std::string ScreenManager::stateName(
    ProcessState state
) const {
    switch (state) {
        case ProcessState::NEW:
            return "New";
        case ProcessState::READY:
            return "Ready";
        case ProcessState::RUNNING:
            return "Running";
        case ProcessState::WAITING:
            return "Sleeping";
        case ProcessState::TERMINATED:
            return "Finished";
    }

    return "Unknown";
}
