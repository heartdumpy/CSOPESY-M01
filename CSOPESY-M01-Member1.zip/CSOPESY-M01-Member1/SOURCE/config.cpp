
#include "config.h"

#include <fstream>
#include <sstream>
#include <unordered_map>
#include <algorithm>
#include <cctype>
#include <vector>

bool loadConfig(
    const std::string& filename,
    Config& config,
    std::string& errorMessage
) {
    std::ifstream file(filename);

    if (!file.is_open()) {
        errorMessage = "Unable to open configuration file: " + filename;
        return false;
    }

    std::unordered_map<std::string, std::string> settings;
    std::string line;
    unsigned int lineNumber = 0;

    const std::vector<std::string> allowedSettings = {
        "num-cpu", "scheduler", "quantum-cycles",
        "batch-process-freq", "min-ins", "max-ins",
        "delays-per-exec"
    };

    while (std::getline(file, line)) {
        ++lineNumber;

        // Ignore comments and blank lines.
        line = line.substr(0, line.find('#'));

        std::istringstream iss(line);
        std::string key;
        std::string value;
        std::string extra;

        if (!(iss >> key)) {
            continue;
        }

        if (!(iss >> value) || (iss >> extra)) {
            errorMessage = "Expected a setting and value at line " +
                std::to_string(lineNumber);
            return false;
        }

        if (std::find(
                allowedSettings.begin(),
                allowedSettings.end(),
                key
            ) == allowedSettings.end()) {
            errorMessage = "Unknown configuration setting: " + key;
            return false;
        }

        if (!settings.emplace(key, value).second) {
            errorMessage = "Duplicate configuration setting: " + key;
            return false;
        }
    }

    if (file.bad()) {
        errorMessage = "Unable to read configuration file.";
        return false;
    }

    const std::string requiredSettings[] = {
        "num-cpu",
        "scheduler",
        "quantum-cycles",
        "batch-process-freq",
        "min-ins",
        "max-ins",
        "delays-per-exec"
    };

    for (const std::string& key : requiredSettings) {
        if (settings.find(key) == settings.end()) {
            errorMessage = "Missing configuration setting: " + key;
            return false;
        }
    }

    Config parsedConfig{};

    try {
        const std::string& cpuValue = settings["num-cpu"];

        if (cpuValue.empty() || !std::all_of(
                cpuValue.begin(),
                cpuValue.end(),
                [](unsigned char character) {
                    return std::isdigit(character) != 0;
                }
            )) {
            errorMessage = "Invalid numeric value for num-cpu";
            return false;
        }

        unsigned long long numCpu = std::stoull(cpuValue);

        if (numCpu < 1 || numCpu > 128) {
            errorMessage = "num-cpu must be between 1 and 128.";
            return false;
        }

        parsedConfig.numCpu = static_cast<int>(numCpu);

        parsedConfig.scheduler = settings["scheduler"];

        if (parsedConfig.scheduler.size() >= 2 &&
            parsedConfig.scheduler.front() == '"' &&
            parsedConfig.scheduler.back() == '"') {
            parsedConfig.scheduler = parsedConfig.scheduler.substr(
                1,
                parsedConfig.scheduler.size() - 2
            );
        }

        if (parsedConfig.scheduler != "fcfs" &&
            parsedConfig.scheduler != "rr") {
            errorMessage = "scheduler must be either fcfs or rr.";
            return false;
        }

        const unsigned long long MAX_VALUE = 4294967296ULL;

        auto parseNumber = [&](const std::string& key,
                               std::uint64_t& destination,
                               bool allowZero) -> bool {
            const std::string& value = settings[key];

            if (value.empty() || !std::all_of(
                    value.begin(),
                    value.end(),
                    [](unsigned char character) {
                        return std::isdigit(character) != 0;
                    }
                )) {
                errorMessage = "Invalid numeric value for " + key;
                return false;
            }

            std::size_t position = 0;
            unsigned long long number = std::stoull(value, &position);

            if (position != value.size()) {
                errorMessage = "Invalid numeric value for " + key;
                return false;
            }

            if ((!allowZero && number < 1) ||
                number > MAX_VALUE) {
                errorMessage = "Value out of range for " + key;
                return false;
            }

            destination = number;
            return true;
        };

        if (!parseNumber("quantum-cycles", parsedConfig.quantumCycles, false))
            return false;

        if (!parseNumber("batch-process-freq", parsedConfig.batchProcessFreq, false))
            return false;

        if (!parseNumber("min-ins", parsedConfig.minIns, false))
            return false;

        if (!parseNumber("max-ins", parsedConfig.maxIns, false))
            return false;

        if (!parseNumber("delays-per-exec", parsedConfig.delaysPerExec, true))
            return false;

        if (parsedConfig.minIns > parsedConfig.maxIns) {
            errorMessage = "min-ins cannot be greater than max-ins.";
            return false;
        }

    } catch (const std::exception&) {
        errorMessage = "Invalid numeric value in configuration file.";
        return false;
    }

    config = parsedConfig;
    errorMessage.clear();
    return true;
}
