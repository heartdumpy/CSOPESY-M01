#include "ConsoleManager.h"

#include <exception>
#include <iostream>

int main() {
    try {
        ConsoleManager console;

        console.run();
    }
    catch (const std::exception& exception) {
        std::cerr
            << "Unable to run emulator: "
            << exception.what()
            << '\n';

        return 1;
    }

    return 0;
}
